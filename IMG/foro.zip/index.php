<html>
<head>
<meta http-equiv="pragma" content="no-cache">
<title>Foro PWeb</title>
</head>
<body>
<? 
$foro = $_GET["foro"];
$guardar = $_GET["guardar"];
$escribir = $_GET["escribir"];
include 'conexion.php';
if ($guardar != '')include 'guardar.php';
if ($escribir != '')include 'escribir.php';
if ($foro != '')include 'foro.php';
if (($guardar == '') && ($escribir == '') && ($foro == ''))include 'lista.php';
?>
</body>
</html>