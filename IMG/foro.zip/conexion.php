<?
$db=mysql_connect('localhost','root','');
mysql_select_db("base_de_datos",$db);
?>